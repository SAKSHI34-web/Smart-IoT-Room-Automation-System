#define BLYNK_TEMPLATE_ID   "YOUR_TEMPLATE_ID"
#define BLYNK_TEMPLATE_NAME "Smart Room Automation"
#define BLYNK_AUTH_TOKEN    "YOUR_DEVICE_AUTH_TOKEN"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <DHT.h>

// Replace with your Wi-Fi credentials.
char ssid[] = "YOUR_WIFI_NAME";
char pass[] = "YOUR_WIFI_PASSWORD";

#define DHT_PIN 4
#define DHTTYPE DHT11
#define PIR_PIN 18
#define LDR_PIN 34
#define OUTPUT_PIN 26

const int LIGHT_THRESHOLD = 1800; // Calibrate using Serial Monitor.
const bool LIGHT_IS_BRIGHT_WHEN_ABOVE = true;
const bool RELAY_ACTIVE_LOW = true;

DHT dht(DHT_PIN, DHTTYPE);
BlynkTimer timer;

bool autoMode = true;
bool manualOutput = false;
bool outputState = false;
int lightLevel = 0;
int motion = 0;

void setOutput(bool enabled) {
  outputState = enabled;
  int level = RELAY_ACTIVE_LOW ? (enabled ? LOW : HIGH)
                              : (enabled ? HIGH : LOW);
  digitalWrite(OUTPUT_PIN, level);
  if (Blynk.connected()) Blynk.virtualWrite(V6, enabled ? 1 : 0);
}

bool roomIsBright(int value) {
  return LIGHT_IS_BRIGHT_WHEN_ABOVE ? value >= LIGHT_THRESHOLD
                                    : value <= LIGHT_THRESHOLD;
}

void readSensors() {
  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature();

  lightLevel = analogRead(LDR_PIN);
  motion = digitalRead(PIR_PIN);

  Serial.print("Temperature: ");
  if (isnan(temperature)) Serial.print("DHT error");
  else Serial.print(temperature);
  Serial.print(" C | Humidity: ");
  if (isnan(humidity)) Serial.print("DHT error");
  else Serial.print(humidity);
  Serial.print(" % | Light: ");
  Serial.print(lightLevel);
  Serial.print(" | Motion: ");
  Serial.println(motion);

  if (Blynk.connected()) {
    if (!isnan(temperature)) Blynk.virtualWrite(V0, temperature);
    if (!isnan(humidity)) Blynk.virtualWrite(V1, humidity);
    Blynk.virtualWrite(V2, lightLevel);
    Blynk.virtualWrite(V3, motion);
  }

  if (autoMode) {
    bool dark = !roomIsBright(lightLevel);
    setOutput(motion == HIGH && dark);
  }
}

BLYNK_WRITE(V4) {
  autoMode = param.asInt() == 1;
  if (autoMode) {
    setOutput(motion == HIGH && !roomIsBright(lightLevel));
  } else {
    setOutput(manualOutput);
  }
}

BLYNK_WRITE(V5) {
  manualOutput = param.asInt() == 1;
  if (!autoMode) setOutput(manualOutput);
}

BLYNK_CONNECTED() {
  Blynk.syncVirtual(V4, V5);
  Blynk.virtualWrite(V6, outputState ? 1 : 0);
}

void setup() {
  Serial.begin(115200);
  pinMode(PIR_PIN, INPUT);
  pinMode(OUTPUT_PIN, OUTPUT);
  pinMode(LDR_PIN, INPUT);
  digitalWrite(OUTPUT_PIN, RELAY_ACTIVE_LOW ? HIGH : LOW);
  analogReadResolution(12); // ESP32 ADC: 0-4095
  dht.begin();

  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);
  timer.setInterval(2000L, readSensors);
}

void loop() {
  Blynk.run();
  timer.run();
}
