# Smart IoT-Based Room Monitoring and Automation System

ESP32 project for monitoring temperature, humidity, light, and motion. Sensor readings are sent to a Blynk IoT dashboard. In automatic mode, a relay output turns on when motion is detected in a dark room. Manual control is also available.

## Hardware
- ESP32 DevKit (classic ESP32)
- DHT11 temperature/humidity sensor
- PIR motion sensor (e.g. HC-SR501)
- LDR and 10 kΩ resistor
- 1-channel relay module compatible with ESP32 3.3 V logic (or an LED for initial testing)
- Breadboard and jumper wires

## Wiring
| Component | ESP32 |
|---|---|
| DHT11 DATA | GPIO 4 |
| PIR OUT | GPIO 18 |
| LDR divider midpoint | GPIO 34 |
| Relay IN | GPIO 26 |
| Module grounds | Common GND |

LDR divider: 3V3 → LDR → GPIO 34 → 10 kΩ resistor → GND. This code assumes higher ADC values mean brighter light.

**Safety:** ESP32 GPIOs are not 5 V tolerant. Confirm module output voltage before connecting. Test with an LED or low-voltage DC load first. Do not connect household mains wiring unless qualified and using properly rated, enclosed equipment.

## Arduino IDE setup
1. Install the ESP32 board package by Espressif Systems.
2. Install libraries: Blynk, DHT sensor library by Adafruit, and Adafruit Unified Sensor.
3. Open `src/SmartRoomAutomation.ino`.
4. Replace the Blynk and Wi-Fi placeholders with your own credentials.
5. Select your ESP32 board and port, then upload.

## Blynk IoT datastreams
Create a Blynk template/device and add:
| Pin | Name | Type |
|---|---|---|
| V0 | Temperature (°C) | Double |
| V1 | Humidity (%) | Double |
| V2 | Light Level (0–4095) | Integer |
| V3 | Motion (0/1) | Integer |
| V4 | Auto Mode (0/1) | Integer |
| V5 | Manual Output (0/1) | Integer |
| V6 | Output Status (0/1) | Integer |

Use value/gauge widgets for V0–V2, indicators for V3 and V6, and switches for V4 and V5.

## Configuration
Set `LIGHT_THRESHOLD` after checking LDR values in Serial Monitor. If your LDR divider gives lower readings in bright light, change `LIGHT_IS_BRIGHT_WHEN_ABOVE`. If your relay is active HIGH, set `RELAY_ACTIVE_LOW` to `false`.

## Logic
- Auto mode ON: output is ON only when motion is detected and the room is dark.
- Auto mode OFF: V5 manually controls the output.

This is an educational prototype; calibrate thresholds and verify module voltage/polarity for your hardware.
