# Wiring reference

| Module | ESP32 connection |
|---|---|
| DHT11 DATA | GPIO 4 |
| PIR OUT | GPIO 18 |
| LDR divider midpoint | GPIO 34 |
| Relay IN | GPIO 26 |
| Grounds | Common GND |

LDR voltage divider: 3V3 → LDR → GPIO 34 → 10 kΩ resistor → GND.

Check all module voltage ratings. ESP32 inputs are not 5 V tolerant. Verify PIR OUT and relay input compatibility before connecting.
