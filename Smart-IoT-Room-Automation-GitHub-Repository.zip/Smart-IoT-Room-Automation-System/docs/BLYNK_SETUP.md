# Blynk IoT setup

Create a Blynk template for ESP32, create a device, and add these virtual-pin datastreams:

| Virtual pin | Name | Type |
|---|---|---|
| V0 | Temperature | Double |
| V1 | Humidity | Double |
| V2 | Light Level | Integer |
| V3 | Motion | Integer |
| V4 | Auto Mode | Integer |
| V5 | Manual Output | Integer |
| V6 | Output Status | Integer |

Add value/gauge widgets for V0–V2, indicators for V3 and V6, and switches for V4 and V5. Copy the Template ID, Template Name, and device Auth Token into the sketch.
